*******************************************************
* Pre-Call announcement with B2BUA Application Module *
*******************************************************

Description:
------------

The annoucement server plays a wav file to the caller.
It searches for files to play following these rules:

 1) [AnnouncePath]/[Domain]/[User].wav
 2) [AnnouncePath]/[User].wav

Then it connects the caller to the r_uri in Back-To-Back 
User Agent (B2BUA) mode, thus staying in the signalling path 
of the call.
