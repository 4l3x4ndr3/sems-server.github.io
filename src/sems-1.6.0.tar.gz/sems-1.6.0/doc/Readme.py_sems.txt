py_sems Readme 

  py_sems is aimed at integrating as much functionnalities
  from the core as possible into python driven applications 
  (not necessarily IVRs), in a more easy way. The classes can 
  then just be used as in C++.

  This plug-in uses the sip4 package included in debian.
  Please refer to http://www.riverbankcomputing.co.uk/sip/
  for more informations on the binding generator.
  Please note that you do not need it, if you just want to compile
  SEMS. You will need it first if you want to generate more classes.

  The version included is 4.1.1. If you generate some files using
  a new version of sip4, update or remove sip.h in the apps/py_sems/sip 
  directory.

  Example applications for py_sems can be found in 
  apps/examples/py_sems_ex.


  This py_sems Readme file is a stub. You can help the community by 
  sending a patch with more information to the semsdev list
  (semsdev@iptel.org).


