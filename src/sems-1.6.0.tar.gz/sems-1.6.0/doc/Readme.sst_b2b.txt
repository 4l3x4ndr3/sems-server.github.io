SIP Session Timers (SST) enabled B2B application.

-------------------------------------------------
This application has been obsoleted by the sbc
module.
Please use the sbc module with the sst_b2b call
profile for the same functionality.
-------------------------------------------------
