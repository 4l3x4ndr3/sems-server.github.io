#ifndef CONFIG_H
#define CONFIG_H

#define SEMS_VERSION "1.1.0-dev"
#define OS "Linux"
#define ARCH "32"

#endif // CONFIG_H
