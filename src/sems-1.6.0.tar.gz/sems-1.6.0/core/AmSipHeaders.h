
#ifndef __AMSIPHEADERS_H__
#define __AMSIPHEADERS_H__

#include "sip/defs.h"

#endif /* __AMSIPHEADERS_H__ */
